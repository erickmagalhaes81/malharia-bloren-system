export default function Home() {
  return (
    <div style={{ padding: "2rem", fontFamily: "Arial" }}>
      <h1>Sistema da Malharia Bloren</h1>
      <p>Projeto online com Next.js!</p>
    </div>
  );
}
