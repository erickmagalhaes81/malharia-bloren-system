export default function Estoque() {
  return <h1>Controle de Estoque</h1>
}