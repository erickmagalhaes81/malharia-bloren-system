export default function Orcamentos() {
  return <h1>Orçamentos</h1>
}