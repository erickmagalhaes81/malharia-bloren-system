export default function Dashboard() {
  return <h1>Painel Administrativo</h1>
}