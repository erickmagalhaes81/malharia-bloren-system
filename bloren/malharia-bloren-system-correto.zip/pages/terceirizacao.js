export default function Terceirizacao() {
  return <h1>Terceirizações</h1>
}