export default function Financeiro() {
  return <h1>Financeiro</h1>
}