
import { useState } from "react";
import Image from "next/image";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";

export default function BlorenSistema() {
  const [clientes, setClientes] = useState([]);
  const [novoCliente, setNovoCliente] = useState("");
  const [pedidos, setPedidos] = useState([]);
  const [novoPedido, setNovoPedido] = useState({ cliente: "", produto: "", quantidade: 0, etapas: {}, custo: 0 });
  const [estoque, setEstoque] = useState([]);
  const [novoInsumo, setNovoInsumo] = useState({ nome: "", quantidade: 0 });
  const [financeiro, setFinanceiro] = useState({ entradas: [], saidas: [] });
  const [novaEntrada, setNovaEntrada] = useState({ descricao: "", valor: 0 });
  const [novaSaida, setNovaSaida] = useState({ descricao: "", valor: 0 });

  const pedidosConcluidos = pedidos.filter(p => p.status === "Concluído").length;
  const pedidosEmProducao = pedidos.filter(p => p.status === "Em produção").length;
  const totalEntradas = financeiro.entradas.reduce((acc, e) => acc + e.valor, 0);
  const totalSaidas = financeiro.saidas.reduce((acc, s) => acc + s.valor, 0);
  const lucro = totalEntradas - totalSaidas;

  function adicionarCliente() {
    if (novoCliente.trim() !== "") {
      setClientes([...clientes, novoCliente]);
      setNovoCliente("");
    }
  }

  function adicionarPedido() {
    if (novoPedido.cliente && novoPedido.produto && novoPedido.quantidade > 0) {
      setPedidos([...pedidos, { ...novoPedido, status: "Em produção", etapas: {
        arte: false,
        impressao: false,
        corte: false,
        costura: false,
        prensagem: false,
        finalizado: false,
      }}]);
      setNovoPedido({ cliente: "", produto: "", quantidade: 0, etapas: {}, custo: 0 });
    }
  }

  function atualizarEtapa(index, etapa) {
    const atualizados = [...pedidos];
    atualizados[index].etapas[etapa] = true;
    if (Object.values(atualizados[index].etapas).every(v => v)) {
      atualizados[index].status = "Concluído";
    }
    setPedidos(atualizados);
  }

  function adicionarInsumo() {
    if (novoInsumo.nome && novoInsumo.quantidade > 0) {
      setEstoque([...estoque, novoInsumo]);
      setNovoInsumo({ nome: "", quantidade: 0 });
    }
  }

  function adicionarEntrada() {
    if (novaEntrada.descricao && novaEntrada.valor > 0) {
      setFinanceiro({ ...financeiro, entradas: [...financeiro.entradas, novaEntrada] });
      setNovaEntrada({ descricao: "", valor: 0 });
    }
  }

  function adicionarSaida() {
    if (novaSaida.descricao && novaSaida.valor > 0) {
      setFinanceiro({ ...financeiro, saidas: [...financeiro.saidas, novaSaida] });
      setNovaSaida({ descricao: "", valor: 0 });
    }
  }

  return (
    <div className="p-4">
      <div className="flex items-center mb-4">
        <Image src="/logo.jpg" alt="Logo Bloren" width={60} height={60} className="mr-4 rounded" />
        <h1 className="text-2xl font-bold">Sistema de Gestão - Malharia Bloren</h1>
      </div>

      <Card className="mb-6">
        <CardContent className="p-4 grid grid-cols-2 md:grid-cols-4 gap-4">
          <div>
            <h2 className="font-semibold">Pedidos em Produção</h2>
            <p>{pedidosEmProducao}</p>
          </div>
          <div>
            <h2 className="font-semibold">Pedidos Concluídos</h2>
            <p>{pedidosConcluidos}</p>
          </div>
          <div>
            <h2 className="font-semibold">Total Entradas (R$)</h2>
            <p>{totalEntradas.toFixed(2)}</p>
          </div>
          <div>
            <h2 className="font-semibold">Lucro Estimado (R$)</h2>
            <p>{lucro.toFixed(2)}</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
