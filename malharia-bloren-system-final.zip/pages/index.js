
export default function Home() {
  return (
    <div style={{ padding: 20 }}>
      <h1>Sistema da Malharia Bloren</h1>
      <p>Projeto online com Next.js!</p>
    </div>
  );
}
